package gov.njdpb.spring_website_monitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebsiteMonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebsiteMonitorApplication.class, args);
	}

}
